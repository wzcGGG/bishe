import numpy as np
import statfile

R0Dict = np.load('R0Dic.npy', allow_pickle='TRUE')

statfile.comparingBoxPlots(R0Dict, plottedData="R0", saveName='comparingModels_0', outputDir='outputs/request_6_facemask_param')